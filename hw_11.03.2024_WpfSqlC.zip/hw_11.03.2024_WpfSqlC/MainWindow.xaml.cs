﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.Common;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;



namespace hw_11._03._2024_WpfSqlC
{
    public partial class MainWindow : Window
    {
        DbConnection conn = null;
        DbProviderFactory fact = null;
        string connString = "";

        public MainWindow()
        {
            InitializeComponent();
            ExecuteButton.IsEnabled = false;
        }

        private void GetAllProviders_Click(object sender, RoutedEventArgs e)
        {
            DataTable dt = DbProviderFactories.GetFactoryClasses();
            MainDataGrid.DataContext = dt;
            DbProviderCB.Items.Clear();
            foreach (DataRow dr in dt.Rows)
            {
                DbProviderCB.Items.Add(dr["InvariantName"]);
            }
        }


        private void QueryExec_Click(object sender, RoutedEventArgs e)
        {
            conn.ConnectionString = connString;
            DbDataAdapter adapter = fact.CreateDataAdapter();
            adapter.SelectCommand = conn.CreateCommand();
            adapter.SelectCommand.CommandText = RequestTB.Text;
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            MainDataGrid.DataContext = dt;
        }

        private void DbProviderCB_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            fact = DbProviderFactories.GetFactory(DbProviderCB.SelectedItem.ToString());
            conn = fact.CreateConnection();
            connString = GetConnectionString(DbProviderCB.SelectedItem.ToString());
            ConnectionStringTB.Text = connString;
        }

        private string GetConnectionString(string providerName)
        {
            string result = null;
            ConnectionStringSettingsCollection settings =
                ConfigurationManager.ConnectionStrings;

            if (settings != null)
            {
                foreach (ConnectionStringSettings cs in settings)
                {
                    if (cs.ProviderName == providerName)
                    {
                        result = cs.ConnectionString;
                        break;
                    }
                }
            }
            return result;
        }

        private void RequestTB_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (RequestTB.Text.Length > 5)
            {
                ExecuteButton.IsEnabled = true;
            }
            else
            {
                ExecuteButton.IsEnabled = false;
            }
        }
    }
}