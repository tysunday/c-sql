﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Shapes;
using System.Data.Common;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System;

namespace hw_11._03._2024_WpfSqlC
{
    public partial class MainWindow : Window
    {
        DbConnection conn = null;
        DbProviderFactory fact = null;
        string connString = "";

        public MainWindow()
        {
            InitializeComponent();
            ExecuteButton.IsEnabled = false;

        }

        private void GetAllProviders_Click(object sender, RoutedEventArgs e)
        {
            DataTable dt = DbProviderFactories.GetFactoryClasses();
            MainDataGrid.DataContext = dt;
            DbProviderCB.Items.Clear();
            foreach (DataRow dr in dt.Rows)
            {
                DbProviderCB.Items.Add(dr["InvariantName"]);
            }
        }


        private void QueryExec_Click(object sender, RoutedEventArgs e)
        {
            conn.ConnectionString = connString;
            DbDataAdapter adapter = fact.CreateDataAdapter();
            adapter.SelectCommand = conn.CreateCommand();
            adapter.SelectCommand.CommandText = RequestTB.Text;
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            MainDataGrid.DataContext = dt;
        }

        private void DbProviderCB_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            fact = DbProviderFactories.GetFactory(DbProviderCB.SelectedItem.ToString());
            conn = fact.CreateConnection();
            connString = GetConnectionString(DbProviderCB.SelectedItem.ToString());
            ConnectionStringTB.Text = connString;
        }

        private string GetConnectionString(string providerName)
        {
            string result = null;
            ConnectionStringSettingsCollection settings =
                ConfigurationManager.ConnectionStrings;

            if (settings != null)
            {
                foreach (ConnectionStringSettings cs in settings)
                {
                    if (cs.ProviderName == providerName)
                    {
                        result = cs.ConnectionString;
                        break;
                    }
                }
            }
            return result;
        }

        private void RequestTB_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (RequestTB.Text.Length > 5)
            {
                ExecuteButton.IsEnabled = true;
            }
            else
            {
                ExecuteButton.IsEnabled = false;
            }
        }

        private void CheckConnectionButton_Click(object sender, RoutedEventArgs e)
        {
            if (connString != string.Empty)
            {
                conn.ConnectionString = connString;
                try
                {
                    conn.Open();
                    if (conn.State == ConnectionState.Open)
                        MessageBox.Show("Соединение с базой данных установлено");
                    else
                        MessageBox.Show("Соединение с базой данных не установлено");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при подключении к базе данных: {ex.Message}");
                }
                finally
                {
                    if (conn.State == ConnectionState.Open)
                        conn.Close();
                }
            }
            else
            {
                MessageBox.Show("Выберите соединение.");
            }
        }
        private void ShowAllStationery_Click(object sender, RoutedEventArgs e)
        {
            if (ConnectionStringTB.Text != string.Empty)
                RequestTB.Text = "SELECT * FROM Stationery";
        }

        private void ShowAllStationeryTypes_Click(object sender, RoutedEventArgs e)
        {
            if (ConnectionStringTB.Text != string.Empty)
                RequestTB.Text = "SELECT DISTINCT Type FROM Stationery";
        }

        private void ShowAllSalesManagers_Click(object sender, RoutedEventArgs e)
        {
            if (ConnectionStringTB.Text != string.Empty)
                RequestTB.Text = "SELECT * FROM Managers";
        }

        private void ShowMaxQuantityStationery_Click(object sender, RoutedEventArgs e)
        {
            if (ConnectionStringTB.Text != string.Empty)
                RequestTB.Text = "SELECT * FROM Stationery WHERE Quantity = (SELECT MAX(Quantity) FROM Stationery)";
        }

        private void ShowMinQuantityStationery_Click(object sender, RoutedEventArgs e)
        {
            if (ConnectionStringTB.Text != string.Empty)
                RequestTB.Text = "SELECT * FROM Stationery WHERE Quantity = (SELECT MIN(Quantity) FROM Stationery)";
        }

        private void ShowMinCostStationery_Click(object sender, RoutedEventArgs e)
        {
            if (ConnectionStringTB.Text != string.Empty)
                RequestTB.Text = "SELECT * FROM Stationery WHERE Cost = (SELECT MIN(Cost) FROM Stationery)";
        }

        private void ShowMaxCostStationery_Click(object sender, RoutedEventArgs e)
        {
            if (ConnectionStringTB.Text != string.Empty)
                RequestTB.Text = "SELECT * FROM Stationery WHERE Cost = (SELECT MAX(Cost) FROM Stationery)";
        }

        private void ShowStationeryByType_Click(object sender, RoutedEventArgs e)
        {
            if (ConnectionStringTB.Text != string.Empty)
                RequestTB.Text = $"SELECT * FROM Stationery WHERE Type = {Convert.ToInt32(RequestTB.Text)}";
        }

        private void ShowStationeryBySalesManager_Click(object sender, RoutedEventArgs e)
        {
            if (ConnectionStringTB.Text != string.Empty)
                RequestTB.Text = $"SELECT * FROM Stationery s INNER JOIN Sales sa ON s.ID = sa.SoldProductID WHERE sa.SellingManagerID = {Convert.ToInt32(RequestTB.Text)}";
        }

        private void ShowStationeryByCustomerCompany_Click(object sender, RoutedEventArgs e)
        {
            if (ConnectionStringTB.Text != string.Empty)
                RequestTB.Text = $"SELECT * FROM Stationery s INNER JOIN Sales sa ON s.ID = sa.SoldProductID WHERE sa.CustomerCompanyID = {Convert.ToInt32(RequestTB.Text)}";
        }

        private void ShowMostRecentSale_Click(object sender, RoutedEventArgs e)
        {
            if (ConnectionStringTB.Text != string.Empty)
                RequestTB.Text = "SELECT TOP 1 * FROM Sales ORDER BY SaleDate DESC";
        }

        private void ShowAverageQuantityByType_Click(object sender, RoutedEventArgs e)
        {
            if (ConnectionStringTB.Text != string.Empty)
                RequestTB.Text = "SELECT Type, AVG(Quantity) as AverageQuantity FROM Stationery GROUP BY Type";
        }

    }
}