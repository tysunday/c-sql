﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Common;
using System.Data.SqlTypes;
using System.Data.SqlClient;
using System.Xml.Linq;
using System.Configuration;

namespace hw_29._02._2024_vegetables_fruits
{
    internal class Program
    {
        static void Main()
        {
            SqlConnection conn = new SqlConnection();

            MySqlFunctions mySqlFunctions = new MySqlFunctions();
            string query = null;

            mySqlFunctions.CheckConnect(conn);

            query = @"SELECT * FROM VegetablesFruits.dbo.VegetablesFruits";
            mySqlFunctions.SelectAllFromQuery(conn, query);

            query = @"SELECT DISTINCT Name FROM VegetablesFruits.dbo.VegetablesFruits";
            mySqlFunctions.SelectAllFromQuery(conn, query);

            query = @"SELECT DISTINCT Color FROM VegetablesFruits.dbo.VegetablesFruits";
            mySqlFunctions.SelectAllFromQuery(conn, query);

            query = @"SELECT MAX(Calories) FROM VegetablesFruits.dbo.VegetablesFruits";
            mySqlFunctions.SelectAllFromQuery(conn, query);

            query = @"SELECT MIN(Calories) FROM VegetablesFruits.dbo.VegetablesFruits";
            mySqlFunctions.SelectAllFromQuery(conn, query);

            query = @"SELECT AVG(Calories) FROM VegetablesFruits.dbo.VegetablesFruits";
            mySqlFunctions.SelectAllFromQuery(conn, query);


            query = @"SELECT COUNT(Id) FROM VegetablesFruits.dbo.VegetablesFruits 
            WHERE Type = 'Vegetable'";
            mySqlFunctions.SelectAllFromQuery(conn, query);

            query = @"SELECT COUNT(Id) FROM VegetablesFruits.dbo.VegetablesFruits 
            WHERE Type = 'Fruit'";
            mySqlFunctions.SelectAllFromQuery(conn, query);

            query = @"SELECT COUNT(Id) FROM VegetablesFruits.dbo.VegetablesFruits 
            WHERE Color = 'Green'";
            mySqlFunctions.SelectAllFromQuery(conn, query);

            query = @"SELECT * FROM VegetablesFruits.dbo.VegetablesFruits 
            WHERE Calories < 26.0";
            mySqlFunctions.SelectAllFromQuery(conn, query);

            query = @"SELECT * FROM VegetablesFruits.dbo.VegetablesFruits 
            WHERE Calories > 26.0";
            mySqlFunctions.SelectAllFromQuery(conn, query);

            query = @"SELECT * FROM VegetablesFruits.dbo.VegetablesFruits 
            WHERE Calories > 10 AND Calories < 20";
            mySqlFunctions.SelectAllFromQuery(conn, query);

            query = @"SELECT * FROM VegetablesFruits.dbo.VegetablesFruits 
            WHERE Color = 'Green' OR Color = 'Red'";
            mySqlFunctions.SelectAllFromQuery(conn, query);

        }
    }

    public class MySqlFunctions
    {
        public void CheckConnect(SqlConnection conn)
        {
            conn.ConnectionString = ConfigurationManager.ConnectionStrings["MyConnString"].ConnectionString;
            using (conn)
            { 
                conn.Open();
                if (conn.State == System.Data.ConnectionState.Open)
                    Console.WriteLine("Подключение успешно установлено.");
                else
                    Console.WriteLine("Ошибка подключения.");
            }
        }
        public void SelectAllFromQuery(SqlConnection conn, string query)
        {
            conn.ConnectionString = ConfigurationManager.ConnectionStrings["MyConnString"].ConnectionString;
            using (conn)
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader rdr = cmd.ExecuteReader();
                int line = 0;
                do
                {
                    line = 0;
                    while (rdr.Read())
                    {
                        if (line == 0)
                        {
                            for (int i = 0; i < rdr.FieldCount; i++)
                                Console.Write(rdr.GetName(i) + "\t\t");
                        }
                        Console.WriteLine();
                        line++;
                        for (int i = 0; i < rdr.FieldCount; i++)
                            Console.Write(rdr[rdr.GetName(i)] + "\t\t");
                    }
                    Console.WriteLine("\n");
                } while (rdr.NextResult());
            }
        }



    }
}