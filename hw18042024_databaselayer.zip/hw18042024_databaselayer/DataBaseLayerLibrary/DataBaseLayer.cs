﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.ComponentModel;
using System.Windows;

namespace DataBaseLayerLibrary
{
    public class DataBaseLayer
    {
        private string connectionString;
        public string ConnectionString
        {
            get { return connectionString; }
            set { connectionString = value; }
        }
        public DataBaseLayer() { }
        public DataBaseLayer(string connString)
        {
            ConnectionString = connString;
        }

        public async Task<bool> CheckConnect()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    await conn.OpenAsync();
                    if (conn.State == System.Data.ConnectionState.Open)
                    {
                        MessageBox.Show("Соединение успешно");
                        return true;
                    }
                    else
                    {
                        MessageBox.Show("Соединение не удалось");
                        return false;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ConnectionString, ex.Message);
                    return false;
                }
            }
        }

        public async Task<DataView> ExecuteQueryAsync(string query)
        {
            DataTable dt = new DataTable();

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                await conn.OpenAsync();

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
                    {
                        dt.Load(reader);
                    }
                }
            }
            return dt.DefaultView;
        }
    }
}
