﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlTypes;
using System.Data.SqlClient;
using System.Configuration;

namespace hw_04._03._2024_stock
{
    internal class Program
    {
        static void Main()
        {
            SqlConnection conn = new SqlConnection();
            MySqlFunctions mySqlFunctions = new MySqlFunctions();
            mySqlFunctions.CheckConnect(conn);
            string query = null;

            mySqlFunctions.CheckConnect(conn);
            query = @"SELECT * FROM Stock.dbo.Products";
            mySqlFunctions.SelectAllFromQuery(conn, query);

            query = @"SELECT DISTINCT Type FROM Stock.dbo.Products";
            mySqlFunctions.SelectAllFromQuery(conn, query);

            query = @"SELECT * FROM Stock.dbo.Providers";
            mySqlFunctions.SelectAllFromQuery(conn, query);

            query = @"SELECT * FROM Stock.dbo.Products p
            WHERE p.Count = (SELECT MAX(Count) FROM Stock.dbo.Products)";
            mySqlFunctions.SelectAllFromQuery(conn, query);

            query = @"SELECT * FROM Stock.dbo.Products p
            WHERE p.Count = (SELECT MIN(Count) FROM Stock.dbo.Products)";
            mySqlFunctions.SelectAllFromQuery(conn, query);

            query = @"SELECT * FROM Stock.dbo.Products p
            WHERE p.Cost = (SELECT MIN(Cost) FROM Stock.dbo.Products)";
            mySqlFunctions.SelectAllFromQuery(conn, query);

            query = @"SELECT * FROM Stock.dbo.Products p
            WHERE p.Cost = (SELECT MAX(Cost) FROM Stock.dbo.Products)";
            mySqlFunctions.SelectAllFromQuery(conn, query);

            query = @"SELECT * FROM Stock.dbo.Products p
            WHERE p.Type = 'Smartphone'";
            mySqlFunctions.SelectAllFromQuery(conn, query);

            query = @"SELECT * FROM Stock.dbo.Products p
            WHERE p.IDProvider = 2";
            mySqlFunctions.SelectAllFromQuery(conn, query);

            query = @"SELECT * FROM Stock.dbo.Products p
            WHERE p.DateAdded = (SELECT MIN(DateAdded) FROM Stock.dbo.Products)";
            mySqlFunctions.SelectAllFromQuery(conn, query);

            query = @"SELECT TYPE, AVG(Count) 
            FROM Stock.dbo.Products 
            GROUP BY TYPE";
            mySqlFunctions.SelectAllFromQuery(conn, query);
        }
    }

    public class MySqlFunctions
    {
        public void CheckConnect(SqlConnection conn)
        {
            conn.ConnectionString = ConfigurationManager.ConnectionStrings["MyConnString"].ConnectionString;
            using (conn)
            {
                conn.Open();
                if (conn.State == System.Data.ConnectionState.Open)
                    Console.WriteLine("Подключение успешно установлено.");
                else
                    Console.WriteLine("Ошибка подключения.");
            }
        }
        public void SelectAllFromQuery(SqlConnection conn, string query)
        {
            conn.ConnectionString = ConfigurationManager.ConnectionStrings["MyConnString"].ConnectionString;
            using (conn)
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader rdr = cmd.ExecuteReader();
                int line = 0;
                do
                {
                    line = 0;
                    while (rdr.Read())
                    {
                        if (line == 0)
                        {
                            for (int i = 0; i < rdr.FieldCount; i++)
                                Console.Write(rdr.GetName(i) + "\t\t");
                        }
                        Console.WriteLine();
                        line++;
                        for (int i = 0; i < rdr.FieldCount; i++)
                            Console.Write(rdr[rdr.GetName(i)] + "\t\t");
                    }
                    Console.WriteLine("\n");
                } while (rdr.NextResult());
            }
        }
    }
}
