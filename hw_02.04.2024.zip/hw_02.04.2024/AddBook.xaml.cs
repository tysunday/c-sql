﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace hw_02._04._2024
{
    public partial class AddBook : Window
    {
        public AddBook()
        {
            InitializeComponent();
        }

        private void AddBookButton_Click(object sender, RoutedEventArgs e)
        {
            using (var db = new BooksEntities())
            {
                try
                {
                    Authors author = new Authors
                    {
                        First_Name = AuthorFirstName.Text,
                        Last_Name  = AuthorLastName.Text,
                    };
                    db.Authors.Add(author);
                    db.SaveChanges();
                    int authorid = author.ID;

                    Books book = new Books
                    {
                        Author_ID = authorid,
                        Title = BookTitle.Text,
                        Read_Pages = Convert.ToInt32(BookReadPages.Text),
                        Total_Pages = Convert.ToInt32(BookTotalPages.Text),
                        Status_ID = Convert.ToInt32(BookStatus.Text),
                        Rating = Convert.ToInt32(Rating.Text),
                    };
                    db.Books.Add(book);
                    db.SaveChanges();
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
     
            }
        }

        private void CloseWindowButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
