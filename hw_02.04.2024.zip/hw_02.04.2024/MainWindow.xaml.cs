﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace hw_02._04._2024
{
    public partial class MainWindow : Window
    {
        int IdBook = 1;
        public MainWindow()
        {
            InitializeComponent();
        }

        void SelectAllDataFromDatabase()
        {
            using (var db = new BooksEntities())
            {
                var data = (from book in db.Books
                            join author in db.Authors on book.Author_ID equals author.ID
                            join status in db.Statuses on book.Status_ID equals status.ID
                            select new
                            {
                                IDBook = book.ID,
                                Title = book.Title,
                                Author = author.First_Name + " " + author.Last_Name,
                                Status = status.Status_Name,
                                PagesRead = book.Read_Pages,
                                TotalPages = book.Total_Pages,
                                Rating = book.Rating,
                            }).ToList();
                MyDataGrid.ItemsSource = data;
            }
        }

        private void EditSomeBookButton_Click(object sender, RoutedEventArgs e)
        {
            EditWindow editWindow = new EditWindow();
            editWindow.Show();
        }

        private void AddBookButton_Click(object sender, RoutedEventArgs e)
        {
            AddBook addbook = new AddBook();
            addbook.Show();
        }

        private void UpdateDataButton_Click(object sender, RoutedEventArgs e)
        {
            SelectAllDataFromDatabase();
            
        }
    }
}
