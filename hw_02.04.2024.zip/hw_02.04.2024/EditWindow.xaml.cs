﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace hw_02._04._2024
{
    /// <summary>
    /// Логика взаимодействия для EditWindow.xaml
    /// </summary>
    public partial class EditWindow : Window
    {
        private List<Books> _books;
    private int _currentBookIndex;
        public EditWindow()
        {
            InitializeComponent();
            using (var db = new BooksEntities())
            {
                _books = db.Books.Include(b => b.Authors).ToList();
            }

            if (_books.Count > 0)
            {
                ShowBook(0);
            }
        }

        private void ShowBook(int index)
        {
            var book = _books[index];
            _currentBookIndex = index;

            TitleTextBox.Text = book.Title;
            AuthorFirstNameTextBox.Text = book.Authors.First_Name;
            AuthorLastNameTextBox.Text = book.Authors.Last_Name;
            ReadPagesTextBox.Text = book.Read_Pages.ToString();
            TotalPagesTextBox.Text = book.Total_Pages.ToString();
            StatusIDTextBox.Text = book.Status_ID.ToString();
            RatingTextBox.Text = book.Rating.ToString();

            PreviousButton.IsEnabled = index > 0;
            NextButton.IsEnabled = index < _books.Count - 1;
        }

        private void SaveCurrentBook()
        {
            using (var db = new BooksEntities())
            {
                var book = db.Books.Find(_books[_currentBookIndex].ID);

                if (book == null)
                {
                    MessageBox.Show("Book not found");
                    return;
                }

                book.Title = TitleTextBox.Text;
                book.Authors.First_Name = AuthorFirstNameTextBox.Text;
                book.Authors.Last_Name = AuthorLastNameTextBox.Text;
                book.Read_Pages = Convert.ToInt32(ReadPagesTextBox.Text);
                book.Total_Pages = Convert.ToInt32(TotalPagesTextBox.Text);
                book.Status_ID = Convert.ToInt32(StatusIDTextBox.Text);
                book.Rating = Convert.ToInt32(RatingTextBox.Text);

                db.Entry(book).State = EntityState.Modified;

                try
                {
                    db.SaveChanges();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Failed to save changes: {ex.Message}");
                    return;
                }

                MessageBox.Show("Changes Saved");
            }
        }

        private void PreviousButton_Click(object sender, RoutedEventArgs e)
        {
            if (_currentBookIndex > 0)
            {
                SaveCurrentBook();
                ShowBook(_currentBookIndex - 1);
            }
        }

        private void NextButton_Click(object sender, RoutedEventArgs e)
        {
            if (_currentBookIndex < _books.Count - 1)
            {
                SaveCurrentBook();
                ShowBook(_currentBookIndex + 1);
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            SaveCurrentBook();
            MessageBox.Show("Changes Saved");
        }
    }
}
